Var1=14
Var2=4
print('{}//{}={}'.format(Var1,Var2,Var1//Var2))