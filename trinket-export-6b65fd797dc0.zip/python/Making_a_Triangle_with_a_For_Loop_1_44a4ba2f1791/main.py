import turtle
pen=turtle.Turtle()
paper=turtle.Screen()
for i in range(3):
  pen.forward(100)
  pen.left(120)