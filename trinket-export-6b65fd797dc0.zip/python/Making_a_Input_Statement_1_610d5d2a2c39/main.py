color=input('What is your favorite color?')
age=input('What is your age?')
print('Your favorite color is '+color+' and your age is '+age )